import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Order2Page } from './order2';

@NgModule({
  declarations: [
    Order2Page,
  ],
  imports: [
    IonicPageModule.forChild(Order2Page),
  ],
})
export class Order2PageModule {}
